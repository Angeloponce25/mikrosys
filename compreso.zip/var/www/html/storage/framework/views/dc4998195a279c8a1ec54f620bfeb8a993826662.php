<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <style>
#invoice{
    padding: 30px;
}

.invoice {
    position: relative;
    background-color: #FFF;
    min-height: 680px;
    padding: 10px
}

.invoice header {
    border-bottom: 1px solid #3989c6
}
.invoice .contacts {
    margin-bottom: 20px
}

.invoice .company-details {
    text-align: left
}

.invoice .company-details .name {
    margin-top: 0;
    margin-bottom: 0;
    color: #3989c6;
}

.invoice .invoice-to {
    text-align: left
}

.invoice .invoice-to .to {
    margin-top: 0;
    margin-bottom: 0
}

.invoice .invoice-details {
    text-align: right
}

.invoice .invoice-details .invoice-id {
    margin-bottom: 40px;
    font-weight:bold;
    color: #3989c6
}

.invoice main {
    padding-bottom: 50px
}

.invoice main .thanks {
    font-size: 12;
    border-left: 6px solid #3989c6
}

.invoice table {
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0;
    margin-bottom: 20px
}

.invoice table td,.invoice table th {
    padding: 15px;
    background: #eee;
    border-bottom: 1px solid #fff
}

.invoice table th {
    white-space: nowrap;
    font-weight: bold;
    color: #3989c6;
    font-size: 16px
}

.invoice table td h3 {
    margin: 0;
    font-weight: bold;
    font-size: 16px;
}

.invoice table .qty,.invoice table .total,.invoice table .unit {
    text-align: right;
    font-size: 16px
}

.invoice table .no {
    font-size: 16px;
}

.invoice table tbody tr:last-child td {
    border: none
}

.invoice table tfoot td {
    background: 0 0;
    border-bottom: none;
    white-space: nowrap;
    text-align: right;
    padding: 10px 20px;
    font-size: 14px;
    border-top: 1px solid #aaa
}

.invoice table tfoot tr:first-child td {
    border-top: none
}

.invoice table tfoot tr:last-child td {
    color: #3989c6;
    font-size: 1.4em;
    border-top: 1px solid #3989c6
}

.invoice table tfoot tr td:first-child {
    border: none
}

.invoice footer {
    width: 100%;
    text-align: center;
    color: #777;
    border-top: 1px solid #aaa;
    padding: 8px 0
    font-size: 10px;
}

@media  print {
    .invoice {
        font-size: 11px!important;
        overflow: hidden!important
    }

    .invoice footer {
        position: absolute;
        bottom: 10px;
        page-break-after: always
    }

    .invoice>div:last-child {
        page-break-before: always
    }
}
    </style>
    </head>
    <body>
    <div id="invoice">
<div class="invoice overflow-auto">
    <div style="min-width: 600px">
        <header>
            <div class="row" style=" margin-bottom: -70px;">
                <div class="col company-details">
                    <h2 class="name">
                        TIFANET
                    </h2>
                    <div>Calle Cesar Vallejo Mz C Lt 8</div>
                    <div>Tel: +51-960273446</div>
                    <div>Email: Angeloponce25@gmail.com</div>
                </div>
                <div class="col invoice-details">
                    <div class="invoice-id">RECIBO N°  00000001</div>
                    <div class="date">Fecha Actual: 01/10/2018</div>
                    <div class="date">Fecha Emision: 30/10/2018</div>
                </div>
            </div>
        </header>
        <main>
            <div class="row contacts">
                <div class="col invoice-to">
                    <div class="text-gray-light">Recibo para:</div>
                    <h2 class="to">Derian Rocha</h2>
                    <div class="address">796 Silver Harbour, TX 79273, US</div>
                    <div class="email">john@example.com</a></div>
                </div>
            </div>
            <table border="0" cellspacing="0" cellpadding="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th class="text-left">DESCRIPCION</th>
                        <th class="text-right">PRECIO</th>
                        <th class="text-right">CANT</th>
                        <th class="text-right">TOTAL</th>
                    </tr>
                </thead>
                <tbody>                    
                    <tr>
                        <td class="no">01</td>
                        <td class="text-left"><h3>Servicio de Internet</h3>Mes : Febrero </td>
                        <td class="unit">S/. 40.00</td>
                        <td class="qty">1</td>
                        <td class="total">S/. 40.00</td>
                    </tr>
                </tbody>
                <tfoot>                    
                    <tr>
                        <td colspan="2"></td>
                        <td style=" font-size:16;font-weight:bold;" colspan="2">TOTAL</td>
                        <td style=" font-size:16;font-weight:bold;">S/. 40.00</td>
                    </tr>
                </tfoot>
            </table>
            <div class="thanks"><b>METODOS DE PAGO</b> <br> <img src="https://www.elquinde.pe/storage/logo-ica-bcp.jpg" alt="BCP" width="102" height="64"><br><b>CUENTA: </b>42537386437085<br> <b>NOMBRE: </b>Loren Llacma Arapa <br> <br>  <img src="https://www.graphicdesignforum.com/uploads/default/1627b8c20c32162a5be29b22b973345403ad5faf" alt="SCOTIABANK" width="102" height="64"><br><b>CUENTA: </b>7940272649<br> <b>NOMBRE: </b>Angelo Ruben Huancapaza Ponce <br></div>            
        </main>
        <footer>
            DOCUMENTO VALIDO PARA PRESENTAR CUALQUIER RECLAMO
        </footer>
    </div>
    <!--DO NOT DELETE THIS div. IT is responsible for showing footer always at the bottom-->
    <div></div>
</div>
</div>

    </body>
</html><?php /**PATH C:\xampp\htdocs\archivos\resources\views/demo.blade.php ENDPATH**/ ?>