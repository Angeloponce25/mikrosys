<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-3">
<div class="card-header ui-sortable-handle" style="cursor: move;">
                <h3 class="card-title">Lista de Clientes</h3>
                <div class="card-tools">
                  <a type="button" href="<?php echo e(route('clientes.crear')); ?>" class="btn btn-block bg-gradient-success btn-xs float-right" title="Agregar Cliente"><i class="fas fa-plus"></i> Agregar</a>
                </div>
              </div>
<div class="card card-solid">
        <div class="card-body pb-0">
          <div class="row d-flex align-items-stretch">
          <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
              <div class="card bg-light">
                <div class="card-header text-muted border-bottom-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  Codigo <?php echo e($item->id); ?>

                </font></font></div>
                <div class="card-body pt-0">
                  <div class="row">
                    <div class="col-7">
                      <h2 class="lead"><b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo e($item->nombre); ?></font></font></b></h2>
                      <p class="text-muted text-sm"><b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Pago Mensual:</font></font></b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo e($item->precio); ?></font></font></p>
                      <ul class="ml-4 mb-0 fa-ul text-muted">
                        <li class="small"><span class="fa-li"><i class="fas fa-lg fa-building"></i></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Direcci�n: <?php echo e($item->direccion); ?></font></font></li>
                        <li class="small"><span class="fa-li"><i class="fas fa-lg fa-phone"></i></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Tel�fono: <?php echo e($item->telefono); ?></font></font></li>
                      </ul>
                    </div>
                    <div class="col-5 text-center">
                      <img src="/storage/user1-128x128.jpg" alt="" class="img-circle img-fluid">
                    </div>
                  </div>
                </div>
                <div class="card-footer">
                  <div class="text-right">                                       
                    <a href="<?php echo e(route('clientedetalle', ['id' => $item->id])); ?>" class="btn btn-sm btn-primary">
                      <i class="fas fa-user"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Ver Perfil-Pagos
                    </font></font></a>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <!-- /.card-body -->
        <div class="card-footer ">
          <nav aria-label="Navegaci�n de la p�gina de contactos">
            <ul class="pagination justify-content-center m-0">
              <?php echo e($clientes ->links()); ?>

            </ul>
          </nav>
          
        </div>
        <!-- /.card-footer -->
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\archivos\archivos\archivos\resources\views/clientes.blade.php ENDPATH**/ ?>