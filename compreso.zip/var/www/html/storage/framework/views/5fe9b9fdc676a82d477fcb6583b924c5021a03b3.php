<footer class="footer">
    <div class="container">
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, Arequipa - Perú
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\archivos\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>