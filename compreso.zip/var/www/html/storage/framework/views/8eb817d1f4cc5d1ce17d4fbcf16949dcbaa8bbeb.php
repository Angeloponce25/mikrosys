<html>
<head>
	<title></title>
</head>
<body>&nbsp;</body>
</html>
<title></title>
<div style="background-color: #f6f6f6;-webkit-font-smoothing: antialiased; -webkit-text-size-adjust: none;-webkit-text-size-adjust: none;width: 100% !important;height: 100%;line-height: 1.6;margin: 0; padding: 0;font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;box-sizing: border-box;font-size: 14px;">
<table class="body-wrap" style="background-color: #f6f6f6;width: 100%;">
	<tbody><tr><td>&nbsp;</td><td style="display: block !important; max-width: 600px !important;margin: 0 auto !important;clear: both !important;" width="600">
		<div style="max-width: 600px;margin: 0 auto;display: block;padding: 20px;">
		<table cellpadding="0" cellspacing="0" style=" background: #fff;border: 1px solid #e9e9e9;border-radius: 3px;" width="100%">
			<tbody><tr><td style="vertical-align: middle;font-size: 16px;color: #fff;font-weight: 500;padding: 15px;border-radius: 3px 3px 0 0;border-bottom: 1px solid #e9e9e9;"><img alt="Mostrar Logo" src="<?php echo e(asset('material')); ?>/img/logo-lgant.png" style="max-height:65px;" />
				<div style="width: auto;color: #348eda;font-weight: 600;float: right;margin: 10px auto;"><span style="font-size:14px;"><span style="color:#66cccc;">RECIBO DE PAGO</span></span></div>
				</td></tr><tr><td style="vertical-align: top;padding: 25px;">
				<table cellpadding="0" cellspacing="0" width="100%">
					<tbody><tr><td style="vertical-align: top;padding: 0px;">Querido(a) &nbsp;<strong><?php echo e($msg['nombre']); ?>,</strong></td></tr><tr><td style="vertical-align: top;padding: 0 0 10px;">
						<p><span style="font-size:12px;">Se trata de un recibo de pago de <strong><?php echo e($msg['mes']); ?> <?php echo e($msg['ano']); ?></strong>&nbsp;registrado&nbsp;el&nbsp;<strong><?php echo e($msg['f_creacion']); ?>.</strong></span></p>

						<p style="line-height: 8px;"><span style="font-size:12px;"><strong>Recibo: #0000000<?php echo e($msg['id_pago']); ?></strong></span></p>

						<p style="line-height: 8px;"><span style="font-size:12px;"><strong>Cantidad:</strong> <?php echo e($msg['monto']); ?>.</span></p>

						<p style="line-height: 8px;"><span style="font-size:12px;"><strong>Fecha de Pago:</strong> <?php echo e($msg['f_impresion']); ?>.</span></p>

						<p><span style="font-size:12px;"><strong>Lugares de Pago:</strong></span></p>

						<ul>
							<li><span style="font-size:12px;"><strong>Mediante Yape:&nbsp;</strong> &nbsp;Loren Llacma Arapa - Telefono : 923 732 984</span></li>
							<li><span style="font-size:12px;"><strong>Transferencia o por&nbsp;</strong><strong>Banco BCP:</strong>&nbsp;Recordamos enviar el comprobante de pago por WhatsApp . Cuenta de&nbsp;Ahorros No.&nbsp;<strong>42537386437085</strong>, Titular .&nbsp;<strong>Loren Llacma Arapa</strong></span></li>
							<li><span style="font-size:12px;"><strong>Transferencia o por&nbsp;</strong><strong>Banco SCOTIABANK:</strong>&nbsp;Recordamos enviar el comprobante de pago por WhatsApp . Cuenta de&nbsp;Ahorros No.&nbsp;<strong>7940272649</strong>, Titular .&nbsp;<strong>Angelo Huancapaza Ponce</strong></span></li>
						</ul>

						<p><span style="font-size:12px;"><strong>Nota:</strong> Este correo electr&oacute;nico servir&aacute; como un recibo oficial para este pago.</span></p>

						</td></tr>
					</tbody>
				</table>
				</td></tr>
			</tbody>
		</table>

		<div style="width: 100%;clear: both;color: #999;padding: 20px;">
		<table width="100%">
			<tbody><tr><td class="aligncenter" style="vertical-align: top; padding: 0px 0px 20px; font-size: 12px;"><strong>Nota:</strong>&nbsp;No responda este correo, Cualquier consulta debe hacerlo &nbsp; a nuestros telefonos.</td></tr>
			</tbody>
		</table>
		</div>
		</div>
		</td><td>&nbsp;</td></tr>
	</tbody>
</table>
</div>
<?php /**PATH /var/www/html/resources/views/emails/comprobante.blade.php ENDPATH**/ ?>