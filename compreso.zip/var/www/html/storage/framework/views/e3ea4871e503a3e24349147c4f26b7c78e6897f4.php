<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Editar usuario</h3>                               
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              	<?php if( session('mensaje_editar') ): ?>
                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('mensaje_editar')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                   </div>
            	<?php endif; ?> 
              <form method="POST" action="<?php echo e(route('usuarios.update', $user->id)); ?>" >
              	<?php echo method_field('PUT'); ?>
              	<?php echo csrf_field(); ?>
              <div class="box-body">
              		<div class="form-group row">
              			<div class="col-sm-6">
                        <label>Nombre</label>
	                  	<input type="text" name="nombre" class="form-control" value="<?php echo e($user->name); ?>" >
                    	</div>                  
	                </div>
	                <div class="form-group row">
	                  	<div class="col-sm-6">
                        <label>Email address</label>
	                  	<input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" >
                    	</div>
	                </div>
	                <div class="form-group row">
	                  	<div class="col-sm-6">
                        <label>Rol</label>
	                  	<input type="text" name="rol" class="form-control" value="<?php echo e($user->rol); ?>" >
                    	</div>
	                </div>
	              </div>
	              <!-- /.box-body -->

	              <div class="box-footer">
	                <div class="col-md-2 float-right">
                  	<button class="btn btn-warning btn-block" type="submit">Editar</button>                
                	</div>
	              </div>
            	</form>             
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\archivos\archivos\resources\views/usuarios/usuarios_editar.blade.php ENDPATH**/ ?>