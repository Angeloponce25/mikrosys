



<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">


            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                  <h4>
                    <i class="fas fa-globe"></i> RECIBO TIFANET.
                    <small class="float-right"><?php echo e(now()); ?></small>
                  </h4>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-sm-8 invoice-col">
                  Para
                  <address>
                    <strong><?php echo e($pagos->cliente->nombre); ?></strong>
                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  <b>Recibo #0000<?php echo e($pagos->id); ?></b><br>
                  <b>Creado por :</b><?php echo e($pagos->usuario->name); ?><br>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                <div class="col-12 table-responsive">
                  <table class="table table-striped">
                    <thead>
                    <tr>
                      <th>#</th>
                      <th>Descripcion</th>
                      <th>Total</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td>1</td>
                      <td>Servicio de Internet <b>(<?php echo e($mensualidad->mes); ?>)</b></td>
                      <td>S/ <?php echo e($pagos->cliente->precio); ?>.00</td>
                    </tr>
                    </tbody>
                  </table>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <div class="row">
                <!-- accepted payments column -->
                <div class="col-6">
                  <p class="lead">Recuerde:</p>
                  <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                    Enviaremos un correo a : <b> <?php echo e($pagos->cliente->email); ?></b> <br>
                    El telefono del cliente es : <b> <?php echo e($pagos->cliente->telefono); ?></b> <br>
                    Servicio de Internet se paga por adelantado
                    
                  </p>
                </div>
                <!-- /.col -->
                <div class="col-6">                  

                  <div class="table-responsive">
                    <table class="table">                      
                      <tr>
                        <th>Total</th>
                        <td>S/ <?php echo e($pagos->cliente->precio); ?>.00</td>
                      </tr>
                    </table>
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- this row will not appear when printing -->
              <div class="row no-print">
                <div class="col-12">
                  <a href="<?php echo e(route('mensualidad.index')); ?>"> <button type="button" class="btn btn-success float-right"><i class="far fa-credit-card"></i> Salir
                  </button></a>
                  <a target="_blank" href="<?php echo e(route('pdf',$pagos->id)); ?>"><button type="button" class="btn btn-primary float-right" style="margin-right: 5px;">
                    <i class="fas fa-download"></i> Descargar PDF
                  </button></a>
                </div>
              </div>
            </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pagoprevia.blade.php ENDPATH**/ ?>