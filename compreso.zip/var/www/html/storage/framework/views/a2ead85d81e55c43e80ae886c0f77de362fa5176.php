



<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
          <div class="card card-primary card-outline">
            <div class="card-body box-profile">
            <h3 class="profile-username text-center">Actualizar Contraseña</h3>
                <?php if( session('exito') ): ?>                    
                    <div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-check"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Exito!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  <?php echo e(session('exito')); ?> </font><font style="vertical-align: inherit;">,Gracias.
                </font></font></div>
                <?php endif; ?>
                <?php if( session('error') ): ?>                    
                    <div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-check"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Exito!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  <?php echo e(session('error')); ?> </font><font style="vertical-align: inherit;">,Gracias.
                </font></font></div>
                <div class="alert alert-danger alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-ban"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Alerta!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  <?php echo e(session('error')); ?> </font><font style="vertical-align: inherit;">,Reintentelo. 
                </font></font></div>
                <?php endif; ?>
                <?php $__errorArgs = ['mypassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-exclamation-triangle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Alerta!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  Tu contraseña Actual es . </font><font style="vertical-align: inherit;"><b>obligatorio</b>.
                </font></font></div>                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-exclamation-triangle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Alerta!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  Tu contraseña Nueva es . </font><font style="vertical-align: inherit;"><b>obligatorio</b>.
                </font></font></div>                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-exclamation-triangle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Alerta!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  Tu contraseña de confirmacion es . </font><font style="vertical-align: inherit;"><b>obligatorio</b>.
                </font></font></div>                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <form method="post" action="<?php echo e(route('updatepassword')); ?>">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="mypassword">Introduce tu actual password:</label>
                <input type="password" name="mypassword" class="form-control" value="<?php echo e(old('mypassword')); ?>">                
              </div>
              <div class="form-group">
                <label for="password">Introduce tu nuevo password:</label>
                <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>">
              </div>
              <div class="form-group">
                <label for="mypassword">Confirma tu nuevo password:</label>
                <input type="password" name="password_confirmation" class="form-control" value="<?php echo e(old('password_confirmation')); ?>">
              </div>
              <button type="submit" class="btn btn-primary">Cambiar mi password</button>
              </form>
            </div>
          </div>

          </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/password.blade.php ENDPATH**/ ?>