



<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-3">
<div class="card-header-tab card-header">
                                <div class="card-header-title font-size-lg text-capitalize font-weight-normal">
                                  <i class="header-icon lnr-laptop-phone mr-3 text-muted opacity-6"> </i>Agregar Clientes
                                </div>
                                
                            </div>    
<div class="card-body">     
                  <?php if( session('mensaje') ): ?>                    
                    <div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-check"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Exito!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  <?php echo e(session('mensaje')); ?> </font><font style="vertical-align: inherit;">,Gracias.
                </font></font></div>
                  <?php endif; ?>
                  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-exclamation-triangle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Alerta!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  El campo Nombre es . </font><font style="vertical-align: inherit;"><b>obligatorio</b>.
                </font></font></div>
                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-exclamation-triangle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Alerta!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  El campo Direccion es . </font><font style="vertical-align: inherit;"><b>obligatorio</b>.
                </font></font></div>
                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-exclamation-triangle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Alerta!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  El campo Email es . </font><font style="vertical-align: inherit;"><b>obligatorio</b>.
                </font></font></div>
                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-exclamation-triangle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Alerta!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  El campo Telefono es . </font><font style="vertical-align: inherit;"><b>obligatorio</b>.
                </font></font></div>
                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                  <h5><i class="icon fas fa-exclamation-triangle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ¡Alerta!</font></font></h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                  El campo Precio es . </font><font style="vertical-align: inherit;"><b>obligatorio</b>.
                </font></font></div>
                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <form method="POST" action="<?php echo e(route('clientes.agregar')); ?>">
                    <?php echo csrf_field(); ?>
                    <input
                      type="text"
                      name="nombre"
                      placeholder="Nombre"
                      class="form-control mb-2"
                      value="<?php echo e(old('nombre')); ?>"
                    />
                    <input
                      type="text"
                      name="direccion"
                      placeholder="Direccion"
                      class="form-control mb-2"
                      value="<?php echo e(old('direccion')); ?>"
                    />
                    <input
                      type="email"
                      name="email"
                      placeholder="Email"
                      class="form-control mb-2"
                      value="<?php echo e(old('email')); ?>"
                    />
                    <input
                      type="tel"
                      name="telefono"
                      placeholder="Telefono"
                      class="form-control mb-2"
                      value="<?php echo e(old('telefono')); ?>"
                    />
                    <input
                      type="number"
                      name="precio"
                      placeholder="Cobro Mensual"
                      class="form-control mb-2"
                      value="<?php echo e(old('precio')); ?>"
                    />
                    <input
                      type="text"
                      name="latitud"
                      id="latitud"
                      placeholder="Latitud"
                      class="form-control mb-2"
                      value="<?php echo e(old('latitud')); ?>"
                    />
                    <input
                      type="text"
                      name="longitud"
                      id="longitud"
                      placeholder="Longitud"
                      class="form-control mb-2"
                      value="<?php echo e(old('longitud')); ?>"
                    />
                    <button class="btn btn-primary btn-block" type="submit">Agregar</button>
                  </form>
                </div>                
                </div>
    <div class="container-fluid">
    <div class="row">
          <div class="col-md-12">
          <?php echo $map['html']; ?>

          </div>
    </div>        
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
    var centreGot = false;    
    </script><?php echo $map['js']; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/archivos/resources/views/clienteagregar.blade.php ENDPATH**/ ?>