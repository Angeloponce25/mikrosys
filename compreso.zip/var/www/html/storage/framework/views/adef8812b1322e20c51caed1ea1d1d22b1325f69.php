<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-3">
<div class="card-header-tab card-header">
                                <div class="card-header-title font-size-lg text-capitalize font-weight-normal">
                                  <i class="header-icon lnr-laptop-phone mr-3 text-muted opacity-6"> </i>Agregar Clientes
                                </div>
                                
                            </div>  
    <div class="card-body">    
                  <?php if( session('mensaje') ): ?>
                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('mensaje')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                   </div>
                  <?php endif; ?>
                  <?php $__errorArgs = ['cliente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Error!</strong> El campo <strong>Cliente ID</strong> es obligatorio.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Error!</strong> El campo <strong>Fecha</strong> es obligatorio.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <form method="POST" action="<?php echo e(route('pagos.crear')); ?>">
                    <?php echo csrf_field(); ?>                    
                    <select class="form-control mb-2" name="cliente_id">                        
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                        
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?></option>                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <input
                      type="text"
                      readonly
                      name="fecha"
                      placeholder="Fecha"
                      class="form-control mb-2"
                      value="<?php echo e(now()); ?>"
                    />
                    <button class="btn btn-primary btn-block" type="submit">Pagar</button>
                  </form>
    </div>
    <div class="card-body">      
                    <table class="table">
                        <thead>
                            <tr>
                            <th scope="col">#</th>
                            <th scope="col">Cliente</th>
                            <th scope="col">Fecha Pago</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($item->id); ?></th>
                                <td><?php echo e($item->cliente->nombre); ?></td>
                                <td><?php echo e($item->fecha); ?></td>                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\archivos\resources\views/pagos.blade.php ENDPATH**/ ?>