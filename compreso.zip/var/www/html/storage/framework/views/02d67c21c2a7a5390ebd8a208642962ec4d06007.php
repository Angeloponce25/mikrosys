<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">        
        <div class="row">
          <div class="col-md-4 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Clientes </font></font></span>
                <span class="info-box-number"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo e($total_clientes); ?></font></font></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-4 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-success"><i class="far fa-flag"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Pagos </font></font></span>
                <span class="info-box-number"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo e($total_pagos); ?></font></font></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-4 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-warning"><i class="far fa-copy"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Usuarios </font></font></span>
                <span class="info-box-number"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo e($total_usuarios); ?></font></font></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div> 
      </div>
    <div class="container-fluid">
    <div class="row">
          <div class="col-md-12">
          <?php echo $map['html']; ?>

          </div>
    </div>        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">var centreGot = false;</script><?php echo $map['js']; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/archivos/resources/views/home.blade.php ENDPATH**/ ?>