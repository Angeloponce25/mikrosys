<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Sistema de Cobranzas Tifanet">
        <meta name="author" content="Angelo Ruben Huancapaza Ponce">

        <title>Sistema Tifanet</title>
        <link href="https://blackrockdigital.github.io/startbootstrap-stylish-portfolio/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

          <!-- Custom Fonts -->
        <link href="https://blackrockdigital.github.io/startbootstrap-stylish-portfolio/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
        <link href="https://blackrockdigital.github.io/startbootstrap-stylish-portfolio/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="https://blackrockdigital.github.io/startbootstrap-stylish-portfolio/css/stylish-portfolio.min.css" rel="stylesheet">
    </head>
    <body id="page-top">

  <!-- Header -->
  <header class="masthead d-flex">
    <div class="container text-center my-auto">
      <h1 class="mb-1">Sistema Tifanet</h1>
      <h3 class="mb-5">
        <em>Sistema de cobranzas para usuarios</em>
      </h3>     
      
        <div class="row">
            <div class="col-6">
            <a class="btn btn-primary btn-xl js-scroll-trigger" href="<?php echo e(route('login')); ?>">Iniciar Sesion</a>
            </div>
            <div class="col-6">
            <a class="btn btn-primary btn-xl js-scroll-trigger" href="<?php echo e(route('register')); ?>">Registrar Cuenta</a>
            </div>
        </div>
    </div>
    <div class="overlay"></div>
  </header> 

</body>
    <!-- <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Inicio</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Entrar</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Registrarse</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    Laravel
                </div>

                <div class="links">
                    <a href="https://laravel.com/docs">Docs</a>
                    <a href="https://laracasts.com">Laracasts</a>
                    <a href="https://laravel-news.com">News</a>
                    <a href="https://blog.laravel.com">Blog</a>
                    <a href="https://nova.laravel.com">Nova</a>
                    <a href="https://forge.laravel.com">Forge</a>
                    <a href="https://vapor.laravel.com">Vapor</a>
                    <a href="https://github.com/laravel/laravel">GitHub</a>
                </div>
            </div>
        </div>
    </body>-->
</html>
<?php /**PATH /var/www/archivos/resources/views/welcome.blade.php ENDPATH**/ ?>