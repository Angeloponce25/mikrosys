<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-3">
<div class="card-header-tab card-header">
                                <div class="card-header-title font-size-lg text-capitalize font-weight-normal">
                                  <i class="header-icon lnr-laptop-phone mr-3 text-muted opacity-6"> </i>Pagos
                                </div>
                                
                            </div>  
    <div class="card-body">    
                  <?php if( session('mensaje') ): ?>
                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('mensaje')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                   </div>
                  <?php endif; ?>
                  <?php if( session('mensaje_eliminar') ): ?>
                  <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('mensaje_eliminar')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                   </div>
                  <?php endif; ?>
                  <?php $__errorArgs = ['cliente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Error!</strong> El campo <strong>Cliente ID</strong> es obligatorio.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
                  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Error!</strong> El campo <strong>Fecha</strong> es obligatorio.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <form method="POST" action="<?php echo e(route('pagos.crear')); ?>">
                    <?php echo csrf_field(); ?>                    
                    <select class="form-control mb-2" name="cliente_id">                        
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                        
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?> - S/. <?php echo e($item->precio); ?></option>                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <input
                      type="text"
                      readonly
                      name="fecha"
                      placeholder="Fecha"
                      class="form-control mb-2"
                      value="<?php echo e(now()); ?>"
                    />
                    <input
                      type="text"
                      name="detalle"
                      placeholder="Detalle(Opcional)"
                      class="form-control mb-2"
                      value="<?php echo e(old('detalle')); ?>"
                    />
                    <button class="btn btn-primary btn-block" type="submit">Pagar</button>
                  </form>
    </div>
    </div>

<div class="card">
        <div class="card-header">
          <h3 class="card-title">Tabla de Pagos</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i></button>
            <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fas fa-times"></i></button>
          </div>
        </div>
        <div class="card-body p-0">
          <table class="table table-striped projects table-responsive">
              <thead>
                  <tr>
                            <th style="width: 2%"  class="text-center">#</th>
                            <th style="width: 50%" class="text-center">Cliente</th>
                            <th style="width: 8%"  class="text-center">Fecha Pago</th>
                            <th style="width: 25%" class="text-center">Detalle</th>
                            <th style="width: 15%" class="text-center">Accion</th>
                  </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td>
                      <?php echo e($item->id); ?>

                      </td>
                      <td class="text-center">
                      <a href="<?php echo e(route('clientedetalle', ['id' => $item->cliente->id])); ?>"><?php echo e($item->cliente->nombre); ?></a>
                          <br/>
                          <small>
                          S/. <?php echo e($item->cliente->precio); ?>

                          </small>
                      </td>                      
                      <td class="project-state">
                          <span class="badge badge-success"><?php echo e($item->fecha); ?></span>
                      </td>
                      <td class="text-center">
                            <?php echo e($item->detalle); ?>

                      </td>
                      <td class="project-actions text-center">
                      <form action="<?php echo e(route('pagos.eliminar', $item)); ?>" method="POST">
                      <?php echo method_field('DELETE'); ?>
                      <?php echo csrf_field(); ?>

                      <button class="btn btn-danger btn-sm" type="submit">
                              <i class="fas fa-trash">
                              </i>
                              Eliminar
                      </button>
                      </form>                                        
                      </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
        </div>
        <!-- /.card-body -->
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\archivos\resources\views/pagos.blade.php ENDPATH**/ ?>