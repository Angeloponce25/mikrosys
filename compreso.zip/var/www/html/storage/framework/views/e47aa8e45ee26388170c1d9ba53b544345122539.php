<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">Tabla de Pagos</h3>
          
        </div>
        <div class="card-body">
          <table id="tabla" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
              <thead>
                  <tr>
                            <th>#</th>
                            <th>Cliente</th>
                            <th>Fecha Pago</th>
                            <th>Detalle</th>
                            <th>Accion</th>
                  </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td>
                      <?php echo e($item->id); ?>

                      </td>
                      <td class="text-center">
                      <a href="<?php echo e(route('clientedetalle', ['id' => $item->cliente->id])); ?>"><?php echo e($item->cliente->nombre); ?></a>
                          <br/>
                          <small>
                          S/. <?php echo e($item->cliente->precio); ?>

                          </small>
                      </td>                      
                      <td class="project-state">
                          <span class="badge badge-success"><?php echo e($item->created_at); ?></span>
                      </td>
                      <td class="text-center">
                            <?php echo e($item->detalle); ?>

                      </td>
                      <td class="project-actions text-center">
                      <form action="<?php echo e(route('pagos.eliminar', $item)); ?>" method="POST">
                      <?php echo method_field('DELETE'); ?>
                      <?php echo csrf_field(); ?>

                      <button class="btn btn-danger btn-sm" type="submit">
                              <i class="fas fa-trash">
                              </i>
                              Eliminar
                      </button>
                      </form>                                        
                      </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                <tr>
                  <th>#</th>
                  <th>Cliente</th>
                  <th>Fecha Pago</th>
                  <th>Detalle</th>
                  <th>Accion</th>
                </tr>
                </tfoot>
          </table>
        </div>
        <!-- /.card-body -->
      </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.6/css/responsive.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.6/js/responsive.bootstrap4.min.js"></script>

<script type="text/javascript">
    $(function () {
    $('#tabla').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true,
      "language": {
            "processing": "Procesando...",
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "emptyTable": "Ningún dato disponible en esta tabla",
            "info": "Mostrando _START_ al _END_ de _TOTAL_ datos",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "search": "Buscar:",
            "infoThousands": ",",
            "loadingRecords": "Cargando...",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            },
            "aria": {
                "sortAscending": ": Activar para ordenar la columna de manera ascendente",
                "sortDescending": ": Activar para ordenar la columna de manera descendente"
            },
            "buttons": {
                "copy": "Copiar",
                "colvis": "Visibilidad"
            }
        },
        
    });    

  });   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\archivos\archivos\archivos\resources\views/pagos.blade.php ENDPATH**/ ?>